'use strict';
// ===== CONFIG (modifiez ici les probabilités : total = 100) =====
const GAME_CONFIG = { casePrice: 100, startingCredits: 1000, items: 60, winnerIndex: 50, spinMs: 6500, saveKey: 'caserush_v1', sellRate: .8, upgradeEdge: .92, maxUp: 5, gameCdMs: 15 * 60000, dailyMs: 24 * 3600000, freeCaseMs: 2 * 3600000, dailyAmount: 1000, wearMax: 1.6, wearMin: .4, googleClientId: '' };
const RARITIES = {
  milspec:   { label: 'MIL-SPEC',     chance: 55,  color: '#3b82f6', price: [15, 45] },
  restricted:{ label: 'RESTRICTED',   chance: 25,  color: '#6d5cff', price: [50, 120] },
  classified:{ label: 'CLASSIFIED',   chance: 12,  color: '#c026d3', price: [150, 400] },
  covert:    { label: 'COVERT',       chance: 6,   color: '#ef4444', price: [500, 1200] },
  legendary: { label: 'LEGENDARY',    chance: 1.8, color: '#f5c542', price: [2000, 4000] },
  mythic:    { label: 'MYTHIC KNIFE', chance: 0.2, color: '#ffd700', price: [6000, 10000] }
};
const RAW = {
  milspec: ['Phantom-9|Neon Pulse','Vektor|Cyber Grid','Viper|Nightfall','Falcon|Ghost Protocol','Raven|Black Circuit','Spectre|Static Haze','M4X|Ion Drift','Kestrel|Blue Relay'],
  restricted: ['AR-7|Crimson Byte','Spectre|Plasma Core','Vector|Hypernova','Phantom-9|Violet Surge','Viper|Glitch Bloom','Falcon|Ultraviolet','Vektor|Neon Tide'],
  classified: ['M4X|Aurora','AWP-X|Digital Storm','Raven|Void Lotus','AR-7|Synthwave','Kestrel|Pulse Rider','Vector|Mirage Code'],
  covert: ['AWP-X|Red Singularity','AR-7|Blood Circuit','Phantom-9|Redshift','Viper|Inferno Grid'],
  legendary: ['Vector|Golden Hour','M4X|Solar Crown','Falcon|Midas Code'],
  mythic: ['★|Eclipse Karambit','★|Solar Fang','★|Void Talon','★|Nova Butterfly','★|Crimson Huntsman','★|Frost Falchion','★|Phantom Stiletto','★|Abyss M9','★|Ember Bowie','★|Prism Flip']
};
const HUE = { milspec: 215, restricted: 255, classified: 295, covert: 0, legendary: 45, mythic: 50 };

const KN = {
  Karambit:'M44 8 Q118 0 124 66 Q100 34 50 36Z', Butterfly:'M58 42 L150 20 L156 30 L66 54Z', Fang:'M46 36 L138 30 L156 44 L46 50Z',
  Huntsman:'M48 34 L126 28 Q150 34 156 46 L48 50Z', Falchion:'M48 30 Q132 12 158 54 Q104 40 48 48Z', Stiletto:'M46 39 L158 44 L46 49Z',
  M9:'M48 31 L138 30 L158 46 L48 52Z', Bowie:'M48 30 L118 28 L152 46 Q116 54 48 52Z', Flip:'M46 32 Q122 20 154 38 L142 52 L46 50Z',
  Talon:'M44 30 Q124 26 134 78 Q104 48 44 46Z'
};
const GUNS = {
  rifle:{ d:['M98 35 H157 V41 H98Z','M72 56 H86 L92 82 H76Z','M50 56 H62 L57 80 H44Z','M100 31 H112 V35 H100Z'], s:['M30 31 H100 Q104 31 104 36 V56 H30Z','M4 36 L30 31 V56 L10 62Z'] },
  pistol:{ d:['M46 46 H72 L64 80 H44Z','M118 33 H132 V38 H118Z'], s:['M36 28 H120 Q124 28 124 33 V46 H36Z'] },
  smg:{ d:['M96 36 H140 V42 H96Z','M64 54 H78 L80 86 H62Z','M44 54 H56 L52 78 H40Z'], s:['M22 30 H98 V54 H22Z','M4 34 L22 30 V52 L8 56Z'] },
  sniper:{ d:['M104 36 H158 V40 H104Z','M44 12 H90 Q94 12 94 17 V22 H44Z','M60 22 H66 V30 H60Z','M72 56 H84 L88 76 H74Z'], s:['M6 34 L40 30 H108 V54 H40 L6 62Z'] }
};
const GTYPE = { 'AWP-X':'sniper', 'AR-7':'rifle', 'M4X':'rifle', 'Vektor':'rifle', 'Falcon':'pistol', 'Phantom-9':'pistol' };
// ===== SKINS =====
const SKINS = []; let n = 0;
for (const r in RAW) RAW[r].forEach((s, i) => {
  const [w, nm] = s.split('|'), [lo, hi] = RARITIES[r].price;
  SKINS.push({ id: ++n, name: w === '★' ? '★ ' + nm : `${w} | ${nm}`, weapon: w === '★' ? 'Knife' : w, rarity: r,
    price: Math.round(lo + (hi - lo) * ((i * 0.618) % 1)), chance: RARITIES[r].chance / RAW[r].length,
    image: makeSkinSVG(n, r, w === '★', nm, w) });
});
function makeSkinSVG(id, r, knife, nm = '', weapon = '') {
  const h = (HUE[r] + id * 23) % 360, a = `hsl(${h} 90% 60%)`, b = `hsl(${(h + 60) % 360} 90% 45%)`, c = RARITIES[r].color;
  const grad = (k, x2, y2, stops) => `<linearGradient id="${k}${id}" x1="0" y1="0" x2="${x2}" y2="${y2}">${stops}</linearGradient>`;
  const defs = (clip = '') => `<defs>${grad('m', 0, 1, '<stop offset="0" stop-color="#6b7194"/><stop offset=".5" stop-color="#262a44"/><stop offset="1" stop-color="#0b0d1c"/>')}`
    + grad('s', 1, 1, `<stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/>`)
    + grad('g', 0, 1, '<stop offset="0" stop-color="#fff" stop-opacity=".6"/><stop offset=".45" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".5"/>') + clip + '</defs>';
  const P = (d, f, extra = '') => `<path d="${d}" fill="${f}" ${extra}/>`;
  const shadow = '<ellipse cx="80" cy="86" rx="62" ry="3.5" fill="#000" opacity=".4"/>';
  if (knife) {
    const t = nm.split(' ').pop(), blade = KN[t] || KN.Fang;
    let hand = P('M6 33 H48 V51 H6Z', `url(#m${id})`, 'stroke="#000" stroke-opacity=".5"') + P('M46 28 H52 V56 H46Z', `url(#m${id})`, `stroke="${c}"`)
      + [14, 26, 38].map(x => `<circle cx="${x}" cy="42" r="2.2" fill="${c}"/>`).join('');
    if (t === 'Karambit') hand = P('M26 30 L54 36 L46 76 Q34 82 24 72Z', `url(#m${id})`, 'stroke="#000" stroke-opacity=".5"') + `<circle cx="28" cy="74" r="11" fill="none" stroke="${c}" stroke-width="4"/>`;
    if (t === 'Butterfly') hand = P('M10 44 L62 40 L64 52 L12 58Z', `url(#m${id})`, 'stroke="#000"') + P('M14 30 L60 38 L62 46 L12 40Z', `url(#m${id})`, 'stroke="#000"') + `<circle cx="62" cy="43" r="3" fill="${c}"/>`;
    return `<svg viewBox="0 0 160 90">${defs()}${shadow}${hand}${P(blade, `url(#s${id})`, `stroke="${c}" stroke-width="2"`)}${P(blade, `url(#g${id})`)}${P(blade, 'none', 'stroke="#fff" stroke-opacity=".55" stroke-width=".8"')}</svg>`;
  }
  const G = GUNS[weapon === 'Phantom-9' || weapon === 'Falcon' ? 'pistol' : GTYPE[weapon] || ({ Viper:'smg', Spectre:'smg', Vector:'smg', Raven:'smg', Kestrel:'smg' }[weapon]) || 'rifle'];
  const clip = `<clipPath id="c${id}">${G.s.map(p => `<path d="${p}"/>`).join('')}</clipPath>`, v = id % 3;
  const pat = v === 0 ? [0, 1, 2, 3, 4].map(k => `<rect x="${20 + k * 22}" y="0" width="8" height="90" fill="${b}" opacity=".55" transform="skewX(-20)"/>`).join('')
    : v === 1 ? Array.from({ length: 24 }, (_, k) => `<circle cx="${12 + (k % 8) * 14}" cy="${34 + Math.floor(k / 8) * 11}" r="3" fill="${b}" opacity=".6"/>`).join('')
    : [0, 1, 2, 3, 4, 5, 6].map(k => `<path d="M${k * 22} 28 L${k * 22 + 20} 60" stroke="${b}" stroke-width="5" opacity=".6"/>`).join('');
  return `<svg viewBox="0 0 160 90">${defs(clip)}${shadow}${G.d.map(p => P(p, `url(#m${id})`, 'stroke="#000" stroke-opacity=".6"')).join('')}`
    + `${G.s.map(p => P(p, `url(#s${id})`, `stroke="${c}" stroke-width="1.5"`)).join('')}<g clip-path="url(#c${id})">${pat}</g>`
    + `${[...G.d, ...G.s].map(p => P(p, `url(#g${id})`)).join('')}</svg>`;
}

// ===== STATE =====
let state = { credits: GAME_CONFIG.startingCredits, inv: [], stats: { opened: 0, spent: 0, counts: {} }, settings: { muted: false, volume: 0.4 }, seq: 0, pending: {}, done: [], cd: {}, owner: false, cheats: { drop: 0, up100: false }, bpend: {}, battle: null };
let busy = false;
const $ = s => document.querySelector(s), fmt = x => Math.round(x).toLocaleString('fr-FR');
const byId = id => SKINS.find(s => s.id === id);
// ===== USURE / FLOAT : nombre de 0 à 1 (6 décimales), 5 plages de 0,2. Plus il est proche de 0, plus le skin vaut cher =====
// Multiplicateur de valeur : float 0 -> wearMax (x1.6), float 1 -> wearMin (x0.4) ; moyenne = x1 (prix de base)
const WEARS = [
  { label: "NEUF D'USINE", color: '#22c55e' }, { label: 'PEU USÉ', color: '#84cc16' }, { label: 'TESTÉ AU TERRAIN', color: '#eab308' },
  { label: 'TRÈS USÉ', color: '#f97316' }, { label: 'MARQUÉ', color: '#ef4444' }
];
const rollFloat = () => +Math.random().toFixed(6);
const wearIdx = f => Math.min(4, Math.floor(f * 5));
const wearOf = f => WEARS[wearIdx(f)];
const wearMult = f => GAME_CONFIG.wearMax - (GAME_CONFIG.wearMax - GAME_CONFIG.wearMin) * f;
const fl6 = f => f.toFixed(6);
const itemVal = it => Math.round(byId(it.id).price * wearMult(it.f));
const newItem = (id, f) => ({ uid: ++state.seq, id, t: Date.now(), f: typeof f === 'number' && f >= 0 && f <= 1 ? +f.toFixed(6) : rollFloat() });

function saveGame() { if (!GAME_CONFIG.saveKey) return; try { localStorage.setItem(GAME_CONFIG.saveKey, JSON.stringify(state)); } catch (e) {} }
function loadGame() {
  if (!GAME_CONFIG.saveKey) return;
  try { const d = JSON.parse(localStorage.getItem(GAME_CONFIG.saveKey)); if (d) state = { ...state, ...d, stats: { ...state.stats, ...d.stats }, settings: { ...state.settings, ...d.settings } }; }
  catch (e) {}
  if (state.tokens) state.credits += state.tokens; // anciens jetons -> crédits
  delete state.tokens;
  state.inv.forEach(i => { if (typeof i.f !== 'number') i.f = rollFloat(); }); // anciens skins : float attribué une fois
}
function updateBalance() { if (state.owner) state.credits = 999999999; $('#bal').textContent = state.owner ? '∞' : fmt(state.credits); if (me) $('#prof').textContent = (state.owner ? '👑 ' : '👤 ') + me.name; $('#openBtn').disabled = busy; document.querySelectorAll('#multi button').forEach(b => b.disabled = busy); $('#snd').textContent = state.settings.muted ? '🔇' : '🔊'; saveGame(); if (window.updateTimers) updateTimers(); }
function notify(msg, err) { const t = document.createElement('div'); t.className = 'toast' + (err ? ' err' : ''); t.textContent = msg; $('#toasts').append(t); setTimeout(() => t.remove(), 2600); }

// ===== AUDIO (synthé WebAudio ; déposez des fichiers dans assets/sounds/<nom>.mp3 pour les remplacer) =====
const SOUNDS = { click: [600, .05], roulette: [200, .3], tick: [900, .03], slowdown: [300, .2], 'common-drop': [500, .3], 'rare-drop': [700, .5], 'legendary-drop': [900, .9], 'knife-drop': [150, 1.4] };
let ac; const cache = {};
function playSound(name) {
  if (state.settings.muted) return;
  try {
    const [f, d] = SOUNDS[name]; ac = ac || new (window.AudioContext || window.webkitAudioContext)();
    const o = ac.createOscillator(), g = ac.createGain(); o.type = name.includes('drop') ? 'triangle' : 'square';
    o.frequency.setValueAtTime(f, ac.currentTime); if (name.includes('drop')) o.frequency.exponentialRampToValueAtTime(f * 2.5, ac.currentTime + d);
    g.gain.setValueAtTime(state.settings.volume * .3, ac.currentTime); g.gain.exponentialRampToValueAtTime(.001, ac.currentTime + d);
    o.connect(g).connect(ac.destination); o.start(); o.stop(ac.currentTime + d);
  } catch (e) {}
}

// ===== DROP =====
function selectWeightedSkin() {
  const total = SKINS.reduce((s, k) => s + k.chance, 0); let r = Math.random() * total;
  for (const k of SKINS) { if ((r -= k.chance) < 0) return k; } return SKINS[0];
}
function rollSkin() { if (state.owner && state.cheats.drop) return byId(state.cheats.drop); return selectWeightedSkin(); } // le gagnant est fixé AVANT l'animation

function cardHTML(s, extra = '', attr = '', it = null) {
  const wr = it ? wearOf(it.f) : null, v = it ? itemVal(it) : s.price;
  const wear = wr ? `<div class="wear" style="--w:${wr.color}">${wr.label}<span>${fl6(it.f)}</span></div><div class="fbar"><i style="left:${it.f * 100}%"></i></div>` : '';
  return `<div class="card ${extra}" ${attr} style="--c:${RARITIES[s.rarity].color}">${s.image}<b>${s.name}</b><em>${RARITIES[s.rarity].label}</em>${wear}<div class="v">${fmt(v)} CRÉDITS</div></div>`;
}
function rouletteItem(s) { return `<div class="it"><div class="card" style="--c:${RARITIES[s.rarity].color}">${s.image}<small>${s.name}</small></div></div>`; }

let multiN = 1; // nombre de caisses ouvertes en même temps (1 à 3)
const MAX_MULTI = 3;
function refreshMulti() {
  const n = multiN, p = GAME_CONFIG.casePrice * n;
  $('#priceTxt').textContent = `${fmt(p)} CRÉDITS` + (n > 1 ? ` (${n} × ${fmt(GAME_CONFIG.casePrice)})` : '');
  if (!busy) $('#openBtn').textContent = n > 1 ? `OUVRIR ${n} CAISSES` : 'OUVRIR LA CAISSE';
  document.querySelectorAll('#multi button').forEach(b => { b.classList.toggle('on', +b.dataset.n === n); b.disabled = busy; });
}
function rouletteBlocks(n) {
  const box = $('#roulette');
  box.innerHTML = Array.from({ length: n }, () => '<div class="rwrap"><div class="marker">▼</div><div class="mtrack" style="display:flex;will-change:transform"></div><div class="mk2">▲</div></div>').join('');
  return [...box.querySelectorAll('.rwrap')].map(w => ({ box: w, track: w.querySelector('.mtrack') }));
}
async function openCase(free) {
  if (busy) return;
  const isFree = free === true, n = isFree ? 1 : multiN, cost = GAME_CONFIG.casePrice * n;
  if (isFree) { if (cdLeft('free') > 0) return; state.cd.free = Date.now(); }
  else if (state.credits < cost) { notify(n > 1 ? `Crédits insuffisants (${fmt(cost)} requis pour ${n} caisses)` : 'Crédits insuffisants', true); return; }
  busy = true; playSound('click');
  state.stats.opened += n; if (!isFree) { state.credits -= cost; state.stats.spent += cost; }
  const winners = Array.from({ length: n }, rollSkin); updateBalance();
  $('#openBtn').textContent = 'OUVERTURE…';
  $('#roulette').hidden = false;
  const blocks = rouletteBlocks(n);
  await Promise.all(blocks.map((b, i) => animateRoulette(winners[i], b.box, b.track, i > 0)));
  const got = winners.map(w => addToInventory(w));
  if (n === 1) showReward(winners[0], got[0].f); else showMultiReward(winners, got);
  busy = false; updateBalance(); refreshMulti();
}
function showMultiReward(winners, got) {
  const best = winners.reduce((a, b) => (b.price > a.price ? b : a)), R = RARITIES[best.rarity], el = $('#mreward');
  el.style.setProperty('--c', R.color);
  $('#mGrid').innerHTML = winners.map((s, i) => cardHTML(s, '', '', got[i])).join('');
  $('#mTot').textContent = `Valeur totale : ${fmt(got.reduce((a, it) => a + itemVal(it), 0))} CRÉDITS`;
  el.hidden = false;
  const flash = c => { const f = document.createElement('div'); f.className = 'flash'; f.style.background = c; document.body.append(f); setTimeout(() => f.remove(), 800); };
  if (best.rarity === 'classified') { flash('#c026d3'); playSound('rare-drop'); }
  else if (best.rarity === 'covert') { flash('#ef4444'); burst(R.color, 50); playSound('rare-drop'); }
  else if (best.rarity === 'legendary') { burst('#f5c542', 100, 600); playSound('legendary-drop'); }
  else if (best.rarity === 'mythic') { flash('#fff'); burst('#ffd700', 160, 800); document.body.classList.add('shake'); setTimeout(() => document.body.classList.remove('shake'), 600); playSound('knife-drop'); }
  else { burst(R.color, 12, 200); playSound('common-drop'); }
  renderAll();
}

function animateRoulette(winner, boxSel = '#roulette', trackSel = '#track', quiet = false) {
  return new Promise(res => {
    const box = typeof boxSel === 'string' ? $(boxSel) : boxSel, track = typeof trackSel === 'string' ? $(trackSel) : trackSel; box.hidden = false;
    const playSound = (...a) => { if (!quiet) window.playSound(...a); };
    const items = Array.from({ length: GAME_CONFIG.items }, (_, i) => i === GAME_CONFIG.winnerIndex ? winner : selectWeightedSkin());
    track.innerHTML = items.map(rouletteItem).join(''); track.style.transform = 'translateX(0)';
    if (!quiet) (box.closest('#roulette') || box).scrollIntoView({ behavior: 'smooth', block: 'center' });
    const w = track.children[0].offsetWidth, W = box.clientWidth;
    const target = GAME_CONFIG.winnerIndex * w + w / 2 + (Math.random() - .5) * w * .7 - W / 2;
    const t0 = performance.now(), D = GAME_CONFIG.spinMs; let last = -1, slow = false;
    playSound('roulette');
    (function frame(now) {
      const t = Math.min((now - t0) / D, 1), e = 1 - Math.pow(1 - t, 4), x = target * e;
      track.style.transform = `translate3d(${-x}px,0,0)`;
      const idx = Math.floor((x + W / 2) / w); if (idx !== last) { last = idx; playSound('tick'); }
      if (!slow && t > .6) { slow = true; playSound('slowdown'); }
      t < 1 ? requestAnimationFrame(frame) : res();
    })(t0);
  });
}

function addToInventory(s) { const it = newItem(s.id); state.inv.push(it); const c = state.stats.counts; c[s.rarity] = (c[s.rarity] || 0) + 1; return it; }

// ===== RÉVÉLATION =====
function burst(color, count, spread = 400) {
  const p = $('#parts'); p.innerHTML = '';
  for (let i = 0; i < count; i++) { const e = document.createElement('i'), a = Math.random() * 6.28, d = spread * (.3 + Math.random() * .7);
    e.style.cssText = `--pc:${color};--x:${Math.cos(a) * d}px;--y:${Math.sin(a) * d}px;animation-delay:${Math.random() * .2}s`; p.append(e); }
}
function showReward(s, f) {
  const R = RARITIES[s.rarity], el = $('#reward'); el.className = s.rarity; el.style.setProperty('--c', R.color);
  const titles = { milspec: 'DROP', restricted: 'DROP', classified: 'CLASSIFIED', covert: 'COVERT DROP', legendary: '✦ LEGENDARY ✦', mythic: '★ MYTHIC DROP ★' };
  el.querySelector('.rtitle').textContent = titles[s.rarity]; el.querySelector('.rimg').innerHTML = s.image;
  el.querySelector('.rname').textContent = s.name; el.querySelector('.rrar').textContent = R.label; const wr = wearOf(f), rw = el.querySelector('.rwear'); rw.style.setProperty('--w', wr.color); rw.innerHTML = `${wr.label}<span>Float : ${fl6(f)}</span>`; el.querySelector('.rval').textContent = `Valeur : ${fmt(s.price * wearMult(f))} CRÉDITS`;
  el.hidden = false;
  const flash = c => { const f = document.createElement('div'); f.className = 'flash'; f.style.background = c; document.body.append(f); setTimeout(() => f.remove(), 800); };
  if (s.rarity === 'classified') { flash('#c026d3'); playSound('rare-drop'); }
  else if (s.rarity === 'covert') { flash('#ef4444'); burst(R.color, 50); playSound('rare-drop'); }
  else if (s.rarity === 'legendary') { burst('#f5c542', 100, 600); playSound('legendary-drop'); }
  else if (s.rarity === 'mythic') { flash('#fff'); burst('#ffd700', 160, 800); document.body.classList.add('shake'); setTimeout(() => document.body.classList.remove('shake'), 600); playSound('knife-drop'); }
  else { burst(R.color, 12, 200); playSound('common-drop'); }
  renderAll();
}

// ===== RENDUS =====
function renderCollection() {
  const own = new Set(state.inv.map(i => i.id)), pct = Math.round(own.size / SKINS.length * 100);
  $('#colTxt').textContent = `${own.size} / ${SKINS.length} débloqués — ${pct} %`; $('#colBar').style.width = pct + '%';
  $('#colGrid').innerHTML = SKINS.map(s => own.has(s.id) ? cardHTML(s) : `<div class="card lock">${s.image}<b>████████</b><em>LOCKED</em></div>`).join('');
}
function renderStats() {
  const st = state.stats, val = state.inv.reduce((a, i) => a + itemVal(i), 0), best = state.inv.slice().sort((a, b) => itemVal(b) - itemVal(a))[0], bf = state.inv.slice().sort((a, b) => a.f - b.f)[0];
  const my = st.counts.mythic || 0, rate = st.opened ? (my / st.opened * 100).toFixed(2) : '0.00';
  const rows = [['CASES OUVERTES', st.opened], ['CRÉDITS DÉPENSÉS', fmt(st.spent)], ["VALEUR DE L'INVENTAIRE", fmt(val)], ['MEILLEUR DROP', best ? `${byId(best.id).name} (${fl6(best.f)})` : '—'], ['MEILLEUR FLOAT', bf ? fl6(bf.f) : '—'], ['TAUX DE DROP MYTHIC', rate + ' %']];
  $('#statGrid').innerHTML = rows.map(r => `<div class="box"><small>${r[0]}</small><div>${r[1]}</div></div>`).join('');
  const mx = Math.max(1, ...Object.values(st.counts));
  $('#chart').innerHTML = Object.entries(RARITIES).map(([k, R]) => `<div class="ch" style="--c:${R.color}"><span>${R.label}</span><i style="width:${(st.counts[k] || 0) / mx * 70}%"></i><b>${st.counts[k] || 0}</b></div>`).join('');
}

// ===== UI =====
function showPage(p) {
  document.querySelectorAll('.page').forEach(e => e.classList.toggle('on', e.id === p));
  document.querySelectorAll('#nav button').forEach(b => b.classList.toggle('on', b.dataset.page === p)); $('#nav').classList.remove('open'); playSound('click'); renderAll();
}
function bgParticles() {
  const c = $('#bg'), x = c.getContext('2d'); let P = [];
  const rs = () => { c.width = innerWidth; c.height = innerHeight; P = Array.from({ length: 50 }, () => ({ x: Math.random() * c.width, y: Math.random() * c.height, r: Math.random() * 2 + .5, v: Math.random() * .4 + .1, h: Math.random() > .5 ? 260 : 215 })); };
  rs(); addEventListener('resize', rs);
  (function f() { x.clearRect(0, 0, c.width, c.height); P.forEach(p => { p.y -= p.v; if (p.y < 0) p.y = c.height; x.fillStyle = `hsla(${p.h},90%,65%,.6)`; x.beginPath(); x.arc(p.x, p.y, p.r, 0, 6.3); x.fill(); }); requestAnimationFrame(f); })();
}
function init() {
  loadGame();
  $('#fr').innerHTML += Object.entries(RARITIES).map(([k, R]) => `<option value="${k}">${R.label}</option>`).join('');
  document.querySelectorAll('#nav button').forEach(b => b.onclick = () => showPage(b.dataset.page));
  $('#burger').onclick = () => $('#nav').classList.toggle('open');
  $('#openBtn').onclick = () => openCase(false);
  document.querySelectorAll('#multi button').forEach(b => b.onclick = () => { if (busy) return; multiN = Math.min(MAX_MULTI, +b.dataset.n); playSound('click'); refreshMulti(); });
  $('#mCont').onclick = () => { $('#mreward').hidden = true; playSound('click'); };
  refreshMulti();
  $('#cont').onclick = () => { $('#reward').hidden = true; playSound('click'); };
  $('#snd').onclick = () => { state.settings.muted = !state.settings.muted; updateBalance(); };
  $('#prof').onclick = openProfile;
  document.querySelectorAll('[data-add]').forEach(b => b.onclick = () => { state.credits += +b.dataset.add; updateBalance(); notify(`+${b.dataset.add} crédits fictifs`); playSound('click'); });
  $('#fw').innerHTML += WEARS.map((w, k) => `<option value="${k}">${w.label} (${(k * .2).toFixed(1)} – ${((k + 1) * .2).toFixed(1)})</option>`).join('');
  ['q', 'fr', 'fw', 'so'].forEach(i => $('#' + i).oninput = renderInventory);
  const cr = $('#crate'), sp = $('#sparks');
  cr.onmousemove = e => { const r = cr.getBoundingClientRect(), dx = (e.clientX - r.left) / r.width - .5, dy = (e.clientY - r.top) / r.height - .5;
    cr.style.transform = `rotateY(${dx * 22}deg) rotateX(${-dy * 22}deg)`;
    if (Math.random() < .4) { const i = document.createElement('i'); i.style.cssText = `left:${50 + dx * 60}%;top:${50 + dy * 60}%;--x:${(Math.random() - .5) * 90}px;--y:${-30 - Math.random() * 70}px`; sp.append(i); setTimeout(() => i.remove(), 1000); } };
  cr.onmouseleave = () => cr.style.transform = '';
  bgParticles(); renderAll();
}
// ===== VENTE / UPGRADE / TRADE =====
let upSel = new Set(), upTarget = null, upBusy = false, trSel = new Set(), trWant = [];
const sellVal = it => Math.round(itemVal(it) * GAME_CONFIG.sellRate);
const invItem = u => state.inv.find(i => i.uid === u);
const names = ids => ids.map(i => byId(i).name).join(', ') || '—';
const namesF = (ids, fs) => ids.map((i, k) => byId(i).name + (fs && typeof fs[k] === 'number' ? ` [${fl6(fs[k])}]` : '')).join(', ') || '—';
const selCards = (list, set) => list.map(i => cardHTML(byId(i.id), set.has(i.uid) ? 'on' : '', `data-uid="${i.uid}"`, i)).join('') || '<p>Aucun skin.</p>';
const byPrice = (a, b) => itemVal(b) - itemVal(a);
function sellUids(uids) {
  let t = 0;
  uids.forEach(u => { const it = invItem(u); if (it) { t += sellVal(it); state.inv = state.inv.filter(i => i.uid !== u); upSel.delete(u); trSel.delete(u); } });
  state.credits += t; renderAll(); notify(`+${fmt(t)} crédits`); playSound('click');
}
function dupUids() {
  const seen = new Set(), out = [];
  state.inv.slice().sort((a, b) => a.f - b.f).forEach(i => { if (seen.has(i.id)) out.push(i.uid); else seen.add(i.id); });
  return out;
}
// --- Upgrade : chance = valeur sacrifiée / valeur de la cible (la valeur suit la rareté) ---
const upSum = () => [...upSel].reduce((a, u) => { const it = invItem(u); return a + (it ? itemVal(it) : 0); }, 0);
function upChance() {
  const t = upTarget ? byId(upTarget) : null, s = upSum(); if (!t) return 0; if (state.owner && state.cheats.up100) return 100; if (!s) return 0;
  return Math.round(Math.min(90, Math.max(1, s / t.price * 100 * GAME_CONFIG.upgradeEdge)) * 100) / 100;
}
function renderUpgrade() {
  [...upSel].forEach(u => { if (!invItem(u)) upSel.delete(u); });
  $('#upInv').innerHTML = selCards(state.inv.slice().sort(byPrice), upSel);
  const fr = $('#upRar').value;
  $('#upTargets').innerHTML = SKINS.filter(s => !fr || s.rarity === fr).sort((a, b) => a.price - b.price).map(s => cardHTML(s, upTarget === s.id ? 'on' : '', `data-sid="${s.id}"`)).join('');
  const ch = upChance(), t = upTarget ? byId(upTarget) : null;
  $('#wheel').style.background = `conic-gradient(#22c55e 0 ${ch}%,#ef4444 0)`; $('#upPct').textContent = ch.toFixed(2) + ' %';
  $('#upInfo').textContent = t && upSel.size ? `Valeur sacrifiée : ${fmt(upSum())} → cible : ${fmt(t.price)} (${RARITIES[t.rarity].label})` : 'Sélectionnez des skins puis une cible.';
  $('#upGo').disabled = upBusy || !ch;
}
async function doUpgrade() {
  const ch = upChance(); if (upBusy || !ch) return; upBusy = true; renderUpgrade();
  const win = Math.random() * 100 < ch, p = ch / 100, ang = (win ? p * (.05 + Math.random() * .9) : p + (1 - p) * (.05 + Math.random() * .9)) * 360;
  const nd = $('#needle'); nd.style.transition = 'none'; nd.style.transform = 'rotate(0deg)'; void nd.offsetWidth;
  nd.style.transition = 'transform 4s cubic-bezier(.1,.7,.1,1)'; nd.style.transform = `rotate(${1440 + ang}deg)`; playSound('roulette');
  await new Promise(r => setTimeout(r, 4200));
  state.inv = state.inv.filter(i => !upSel.has(i.uid)); upSel.clear();
  const t = byId(upTarget); upBusy = false;
  if (win) { const ni = newItem(t.id); state.inv.push(ni); showReward(t, ni.f); }
  else { notify('Upgrade raté : skins perdus', true); renderAll(); }
}
// --- Trade par codes ---
const enc = o => 'CR1.' + btoa(JSON.stringify(o));
function showCode(label, code) {
  $('#trOut').innerHTML = `<p>${label}</p><textarea readonly id="trOutTa">${code}</textarea><button id="trCopy">COPIER</button>`;
  $('#trCopy').onclick = () => { $('#trOutTa').select(); try { navigator.clipboard.writeText(code); } catch (e) { document.execCommand('copy'); } notify('Code copié'); };
}
function renderTrade() {
  [...trSel].forEach(u => { if (!invItem(u)) trSel.delete(u); });
  $('#trInv').innerHTML = selCards(state.inv.slice().sort(byPrice), trSel);
  $('#trWantList').innerHTML = trWant.map((id, i) => `<span class="chip">${byId(id).name}<button data-i="${i}">✕</button></span>`).join('') || '<small>Aucun (cadeau)</small>';
  $('#trPend').innerHTML = Object.entries(state.pending).map(([id, p]) => `<div class="pend"><b>Offre ${id}</b><br>Vous donnez : ${namesF(p.g, p.gf)}<br>Vous demandez : ${names(p.w)}<br><button data-code="${id}">VOIR LE CODE</button> <button data-cancel="${id}">ANNULER</button></div>`).join('') || '<small>Aucune offre en attente.</small>';
}
function makeOffer() {
  const g = [...trSel].map(invItem).filter(Boolean); if (!g.length) { notify('Sélectionnez au moins un skin à donner', true); return; }
  const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 5), gi = g.map(i => i.id), gf = g.map(i => i.f), c = enc({ t: 'o', id, g: gi, gf, w: [...trWant] });
  state.inv = state.inv.filter(i => !trSel.has(i.uid)); trSel.clear(); state.pending[id] = { g: gi, gf, w: [...trWant], c }; trWant = [];
  renderAll(); showCode("Envoyez ce code à l'autre joueur (vos skins sont mis de côté) :", c);
}
function importCode() {
  const raw = $('#trCode').value.trim(), ok = a => Array.isArray(a) && a.length <= 20 && a.every(x => Number.isInteger(x) && byId(x)), okf = a => a === undefined || (Array.isArray(a) && a.length <= 20 && a.every(x => typeof x === 'number' && x >= 0 && x <= 1)); let o;
  try { if (!raw.startsWith('CR1.')) throw 0; o = JSON.parse(atob(raw.slice(4))); if (!o.id || !ok(o.w) || (o.t === 'o' && !ok(o.g)) || !okf(o.gf) || !okf(o.wf)) throw 0; } catch (e) { notify('Code invalide', true); return; }
  if (o.t === 'o') {
    if (state.pending[o.id]) { notify("C'est votre propre offre", true); return; }
    if (state.done.includes(o.id)) { notify('Offre déjà utilisée', true); return; }
    const pool = state.inv.slice(), take = [], wf = [];
    for (const sid of o.w) { const k = pool.findIndex(i => i.id === sid); if (k < 0) { notify('Il vous manque : ' + names(o.w), true); return; } const it = pool.splice(k, 1)[0]; take.push(it.uid); wf.push(it.f); }
    if (!confirm(`Vous recevez : ${namesF(o.g, o.gf)}\nVous donnez : ${namesF(o.w, wf)}\nAccepter ?`)) return;
    state.inv = state.inv.filter(i => !take.includes(i.uid)); o.g.forEach((id, k) => state.inv.push(newItem(id, o.gf && o.gf[k]))); state.done.push(o.id);
    take.forEach(u => { upSel.delete(u); trSel.delete(u); }); $('#trCode').value = ''; renderAll(); notify('Échange effectué !');
    if (o.w.length) showCode("Renvoyez ce code à l'autre joueur pour qu'il reçoive ses skins :", enc({ t: 'r', id: o.id, w: o.w, wf })); else $('#trOut').innerHTML = '';
  } else if (o.t === 'r') {
    const p = state.pending[o.id]; if (!p || [...p.w].sort().join() !== [...o.w].sort().join()) { notify('Aucune offre correspondante', true); return; }
    o.w.forEach((id, k) => state.inv.push(newItem(id, o.wf && o.wf[k]))); delete state.pending[o.id]; $('#trCode').value = ''; renderAll(); notify('Échange finalisé : ' + names(o.w));
  } else notify('Code invalide', true);
}
function initExtra() {
  $('#upRar').innerHTML += Object.entries(RARITIES).map(([k, R]) => `<option value="${k}">${R.label}</option>`).join('');
  $('#trWant').innerHTML = SKINS.slice().sort((a, b) => a.name.localeCompare(b.name)).map(s => `<option value="${s.id}">${s.name}</option>`).join('');
  $('#upRar').oninput = renderUpgrade; $('#grp').onchange = renderInventory; $('#upGo').onclick = doUpgrade; $('#trMake').onclick = makeOffer; $('#trImport').onclick = importCode;
  const pick = (set, max) => e => { const c = e.target.closest('[data-uid]'); if (!c || upBusy) return; const u = +c.dataset.uid;
    if (set.has(u)) set.delete(u); else if (set.size < max) set.add(u); else notify(`Maximum ${max} skins`, true); renderAll(); };
  $('#upInv').onclick = pick(upSel, GAME_CONFIG.maxUp); $('#trInv').onclick = pick(trSel, 20);
  $('#upTargets').onclick = e => { const c = e.target.closest('[data-sid]'); if (c && !upBusy) { upTarget = +c.dataset.sid; renderUpgrade(); } };
  $('#trAdd').onclick = () => { if (trWant.length < 20) trWant.push(+$('#trWant').value); renderTrade(); };
  $('#trWantList').onclick = e => { const b = e.target.closest('[data-i]'); if (b) { trWant.splice(+b.dataset.i, 1); renderTrade(); } };
  $('#trPend').onclick = e => { const c = e.target.closest('[data-code]'), x = e.target.closest('[data-cancel]');
    if (c) showCode('Code de votre offre :', state.pending[c.dataset.code].c);
    if (x && confirm('Annuler cette offre et récupérer vos skins ?')) { const pd = state.pending[x.dataset.cancel]; pd.g.forEach((id, k) => state.inv.push(newItem(id, pd.gf && pd.gf[k]))); delete state.pending[x.dataset.cancel]; renderAll(); } };
  $('#invGrid').onclick = e => { const b = e.target.closest('.sell'); if (b) sellUids([+b.dataset.uid]); };
  $('#sellDup').onclick = () => { const d = dupUids(); if (!d.length) notify('Aucun doublon', true); else if (confirm(`Vendre ${d.length} doublon(s) ?`)) sellUids(d); };
  $('#sellAll').onclick = () => { if (state.inv.length && confirm('Vendre TOUT votre inventaire ?')) sellUids(state.inv.map(i => i.uid)); };
}
function renderInventory() {
  const q = $('#q').value.toLowerCase(), fr = $('#fr').value, fw = $('#fw').value, so = $('#so').value;
  let l = state.inv.map(i => ({ ...i, s: byId(i.id) })).filter(i => i.s.name.toLowerCase().includes(q) && (!fr || i.s.rarity === fr) && (fw === '' || wearIdx(i.f) === +fw));
  l.sort((a, b) => so === 'hi' ? itemVal(b) - itemVal(a) : so === 'lo' ? itemVal(a) - itemVal(b) : so === 'fl' ? a.f - b.f : so === 'fh' ? b.f - a.f : so === 'old' ? a.t - b.t : b.t - a.t);
  if ($('#grp').checked) { const m = new Map(); l = l.filter(i => { const k = m.get(i.id); if (k) { k.n++; return false; } i.n = 1; m.set(i.id, i); return true; }); }
  $('#invCount').textContent = `${state.inv.length} SKINS`;
  $('#invGrid').innerHTML = l.map(i => `<div class="iw">${i.n > 1 ? `<span class="qty">x${i.n}</span>` : ''}${cardHTML(i.s, '', `data-uid="${i.uid}"`, i)}<button class="sell" data-uid="${i.uid}">VENDRE · ${fmt(sellVal(i))} CRÉDITS</button></div>`).join('') || '<p>Aucun skin pour le moment — ouvrez une caisse !</p>';
}
function renderAll() { renderBattle(); renderInventory(); renderCollection(); renderStats(); renderUpgrade(); renderTrade(); updateBalance(); }

// ===== BONUS, CAISSE GRATUITE, MINI-JEUX =====
const cdMs = k => k === 'daily' ? GAME_CONFIG.dailyMs : k === 'free' ? GAME_CONFIG.freeCaseMs : GAME_CONFIG.gameCdMs;
const cdLeft = k => state.owner ? 0 : Math.max(0, (state.cd[k] || 0) + cdMs(k) - Date.now());
const fmtT = ms => { const s = Math.ceil(ms / 1000), p = n => String(n).padStart(2, '0'); return `${p(Math.floor(s / 3600))}:${p(Math.floor(s % 3600 / 60))}:${p(s % 60)}`; };
function updateTimers() {
  document.querySelectorAll('[data-cd]').forEach(e => { const l = cdLeft(e.dataset.cd); e.textContent = l ? fmtT(l) : 'DISPONIBLE'; });
  document.querySelectorAll('[data-g]').forEach(b => b.disabled = cdLeft(b.dataset.g) > 0);
  $('#daily').disabled = cdLeft('daily') > 0; $('#freeBtn').disabled = busy || cdLeft('free') > 0;
}
function claimDaily() {
  if (cdLeft('daily') > 0) return; state.cd.daily = Date.now(); state.credits += GAME_CONFIG.dailyAmount;
  renderAll(); notify(`+${fmt(GAME_CONFIG.dailyAmount)} crédits (bonus quotidien)`); playSound('rare-drop');
}
const GAMES = {
  reflex: { name: 'Clic éclair', desc: 'Cliquez dès que l\'écran devient vert.', max: 200, run(b, end) {
    b.innerHTML = '<div class="rf">Attendez le vert…</div>'; const d = b.firstChild; let go = 0, done = false;
    const t = setTimeout(() => { go = performance.now(); d.className = 'rf go'; d.textContent = 'CLIQUEZ !'; }, 1000 + Math.random() * 3000);
    d.onclick = () => { if (done) return; done = true; clearTimeout(t); if (!go) return end(0, 'Trop tôt !'); const ms = Math.round(performance.now() - go); end(Math.max(20, Math.min(200, Math.round(260 - ms * .3))), `Temps : ${ms} ms`); };
    return () => clearTimeout(t); } },
  target: { name: 'Tir sur cible', desc: 'Touchez un maximum de cibles en 15 s.', max: 200, run(b, end) {
    b.innerHTML = '<p id="tgs">Score 0 · 15 s</p><div class="tgz"><i id="tgt"></i></div>'; let hits = 0, left = 15; const t = $('#tgt');
    const mv = () => { t.style.left = Math.random() * 88 + '%'; t.style.top = Math.random() * 80 + '%'; }; mv();
    t.onclick = () => { hits++; mv(); $('#tgs').textContent = `Score ${hits} · ${left} s`; playSound('tick'); };
    const iv = setInterval(() => { left--; $('#tgs').textContent = `Score ${hits} · ${left} s`; if (left <= 0) { clearInterval(iv); end(Math.min(200, hits * 8), `${hits} cibles touchées`); } }, 1000);
    return () => clearInterval(iv); } },
  guess: { name: 'Plus ou moins', desc: 'Devinez un nombre de 1 à 100 en 7 essais.', max: 210, run(b, end) {
    const n = 1 + Math.floor(Math.random() * 100); let tries = 0;
    b.innerHTML = '<p id="gh">Devinez un nombre entre 1 et 100 (7 essais).</p><input id="gi" type="number" min="1" max="100"> <button id="gok">VALIDER</button>';
    $('#gok').onclick = () => { const v = +$('#gi').value; if (!v || v < 1 || v > 100) return; tries++;
      if (v === n) return end((8 - tries) * 30, `Trouvé en ${tries} essai(s) !`); if (tries >= 7) return end(0, `Perdu ! C'était ${n}`);
      $('#gh').textContent = `${v < n ? 'Plus grand' : 'Plus petit'} — essais restants : ${7 - tries}`; $('#gi').value = ''; }; } },
  simon: { name: 'Mémoire', desc: 'Reproduisez la séquence de couleurs (8 manches max).', max: 200, run(b, end) {
    const cols = ['#ef4444', '#22c55e', '#3b82f6', '#eab308']; let seq = [], step = 0, round = 0, lock = true; const timers = [];
    b.innerHTML = '<p id="sm">Regardez…</p><div class="sim">' + cols.map((c, i) => `<button data-i="${i}" style="background:${c}"></button>`).join('') + '</div>';
    const bs = b.querySelectorAll('.sim button'), flash = i => { bs[i].classList.add('lit'); setTimeout(() => bs[i].classList.remove('lit'), 350); playSound('tick'); };
    const next = () => { if (round >= 8) return end(200, 'Parfait : 8 manches !'); seq.push(Math.floor(Math.random() * 4)); step = 0; lock = true; $('#sm').textContent = `Manche ${round + 1} — regardez`;
      seq.forEach((s, k) => timers.push(setTimeout(() => flash(s), 600 + k * 600))); timers.push(setTimeout(() => { lock = false; $('#sm').textContent = 'À vous !'; }, 600 + seq.length * 600)); };
    b.querySelector('.sim').onclick = e => { const x = e.target.closest('button'); if (!x || lock) return; const i = +x.dataset.i; flash(i);
      if (i !== seq[step]) { lock = true; return end(round * 25, `Raté à la manche ${round + 1}`); } step++; if (step === seq.length) { round++; lock = true; timers.push(setTimeout(next, 700)); } };
    next(); return () => timers.forEach(clearTimeout); } },
  mines: { name: 'Diamants', desc: '12 cases, 3 bombes. Encaissez avant d\'exploser.', max: 225, run(b, end) {
    const bombs = new Set(); while (bombs.size < 3) bombs.add(Math.floor(Math.random() * 12)); let got = 0, tm;
    b.innerHTML = '<p id="mp">Évitez les 3 bombes. Gain : 0</p><div class="mg">' + Array.from({ length: 12 }, (_, i) => `<button data-i="${i}">?</button>`).join('') + '</div><button id="mc">ENCAISSER</button>';
    const bs = b.querySelectorAll('.mg button');
    b.querySelector('.mg').onclick = e => { const x = e.target.closest('button'); if (!x || x.disabled) return; x.disabled = true;
      if (bombs.has(+x.dataset.i)) { bs.forEach((y, k) => { if (bombs.has(k)) y.textContent = '💣'; }); tm = setTimeout(() => end(0, 'BOOM !'), 900); return; }
      x.textContent = '💎'; got += 25; $('#mp').textContent = `Évitez les 3 bombes. Gain : ${got}`; if (got >= 225) end(got, 'Tout trouvé !'); };
    $('#mc').onclick = () => { if (got > 0) end(got, 'Encaissé !'); }; return () => clearTimeout(tm); } }
};
let gClean = null, gEnded = false;
function launchGame(k) {
  if (cdLeft(k) > 0) { notify('Pas encore disponible', true); return; }
  state.cd[k] = Date.now(); const g = GAMES[k]; gEnded = false; $('#gt').textContent = g.name; $('#gameModal').hidden = false; updateBalance();
  gClean = g.run($('#gBody'), (r, m) => { if (gEnded) return; gEnded = true; state.credits += r; $('#gBody').innerHTML = `<h3>${m}</h3><p class="rval">+${fmt(r)} CRÉDITS</p>`; renderAll(); playSound(r ? 'rare-drop' : 'click'); });
}
function initGames() {
  $('#gmGrid').innerHTML = Object.entries(GAMES).map(([k, g]) => `<div class="gcard"><h3>${g.name}</h3><p>${g.desc}</p><small>Gain max : ${g.max} crédits</small><button data-g="${k}">JOUER</button><small data-cd="${k}"></small></div>`).join('');
  $('#gmGrid').onclick = e => { const b = e.target.closest('[data-g]'); if (b) launchGame(b.dataset.g); };
  $('#gClose').onclick = () => { if (gClean) gClean(); gClean = null; $('#gameModal').hidden = true; };
  $('#daily').onclick = claimDaily; $('#freeBtn').onclick = () => openCase(true);
  setInterval(updateTimers, 1000);
}

// ===== COMPTES, OWNER, CHEATS =====
const OWNER_HASH = 'b99dbe664f039316b942841272870c5d239a1d8a74e8b4830a9d0313e623fcbc';
const ACC_KEY = 'caserush_accounts', SES_KEY = 'caserush_session';
let me = null;
const getAcc = () => { try { return JSON.parse(localStorage.getItem(ACC_KEY)) || {}; } catch (e) { return {}; } };
const setAcc = a => localStorage.setItem(ACC_KEY, JSON.stringify(a));
const hex = b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
async function sha(str) { return hex(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str))); }
async function pbk(pw, salt) {
  const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(pw), 'PBKDF2', false, ['deriveBits']);
  return hex(await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: new TextEncoder().encode(salt), iterations: 100000, hash: 'SHA-256' }, k, 256));
}
async function ownerOk(code) { return (await sha(code.trim().toLowerCase().replace(/\s+/g, ' '))) === OWNER_HASH; }
function startSession(id) {
  const k = 'caserush_v1_' + id, legacy = localStorage.getItem('caserush_v1');
  if (legacy && !localStorage.getItem(k) && !localStorage.getItem('caserush_legacy_taken')) { localStorage.setItem(k, legacy); localStorage.setItem('caserush_legacy_taken', '1'); }
  localStorage.setItem(SES_KEY, id); location.reload();
}
let authMode = 'log';
async function authSubmit() {
  const u = $('#aUser').value.trim(), p = $('#aPass').value, err = m => $('#aErr').textContent = m, id = 'u:' + u.toLowerCase();
  if (!window.crypto || !crypto.subtle) return err('Navigateur non compatible : ouvrez le jeu via https ou http://localhost.');
  if (!/^[A-Za-z0-9_-]{3,16}$/.test(u)) return err('Pseudo : 3 à 16 caractères (lettres, chiffres, _ ou -).');
  if (p.length < 6) return err('Mot de passe : 6 caractères minimum.');
  const acc = getAcc();
  if (authMode === 'reg') {
    if (acc[id]) return err('Ce pseudo existe déjà.');
    const salt = hex(crypto.getRandomValues(new Uint8Array(16)));
    acc[id] = { name: u, type: 'local', salt, hash: await pbk(p, salt) }; setAcc(acc); startSession(id);
  } else {
    const a = acc[id]; if (!a || a.type !== 'local' || (await pbk(p, a.salt)) !== a.hash) return err('Pseudo ou mot de passe incorrect.');
    startSession(id);
  }
}
function setAuthMode(m) {
  authMode = m; $('#tLog').classList.toggle('on', m === 'log'); $('#tReg').classList.toggle('on', m === 'reg');
  $('#aGo').textContent = m === 'reg' ? 'CRÉER LE COMPTE' : 'SE CONNECTER'; $('#aErr').textContent = '';
}
const jwt = t => JSON.parse(decodeURIComponent(escape(atob(t.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')))));
function googleLogin() {
  const err = m => $('#aErr').textContent = m;
  if (!GAME_CONFIG.googleClientId) return err('Google non configuré : renseignez googleClientId dans GAME_CONFIG (script.js).');
  const go = () => {
    google.accounts.id.initialize({ client_id: GAME_CONFIG.googleClientId, callback: r => {
      try { const p = jwt(r.credential), id = 'g:' + p.sub, acc = getAcc(); acc[id] = { name: p.name || p.email, type: 'google' }; setAcc(acc); startSession(id); } catch (e) { err('Échec de la connexion Google.'); } } });
    $('#aGoogle').hidden = true; google.accounts.id.renderButton($('#gbtn'), { theme: 'filled_black', size: 'large' });
  };
  if (window.google && google.accounts) go();
  else { const s = document.createElement('script'); s.src = 'https://accounts.google.com/gsi/client'; s.onload = go; s.onerror = () => err('Impossible de charger Google (hors-ligne ?).'); document.head.append(s); }
}
function renderProfile() {
  $('#pName').textContent = (state.owner ? '👑 ' : '👤 ') + (me ? me.name : '');
  $('#pInfo').textContent = me && me.id.startsWith('g:') ? 'Compte Google' : 'Compte local';
  $('#ownerPanel').hidden = !state.owner; $('#chUp').checked = !!state.cheats.up100; $('#chDrop').value = state.cheats.drop || 0;
}
function openProfile() { renderProfile(); $('#profile').hidden = false; }
function initAuth() {
  const id = localStorage.getItem(SES_KEY), acc = getAcc();
  $('#tLog').onclick = () => setAuthMode('log'); $('#tReg').onclick = () => setAuthMode('reg'); $('#aGo').onclick = authSubmit; $('#aGoogle').onclick = googleLogin;
  $('#aPass').onkeydown = e => { if (e.key === 'Enter') authSubmit(); };
  if (id && acc[id]) { me = { id, name: acc[id].name }; GAME_CONFIG.saveKey = 'caserush_v1_' + id; $('#prof').textContent = '👤 ' + me.name; }
  else { GAME_CONFIG.saveKey = null; $('#auth').hidden = false; }
  $('#chDrop').innerHTML = '<option value="0">Aucun (aléatoire)</option>' + SKINS.map(s => `<option value="${s.id}">${s.name}</option>`).join('');
  $('#chAdd').innerHTML = SKINS.map(s => `<option value="${s.id}">${s.name}</option>`).join('');
  $('#pClose').onclick = () => $('#profile').hidden = true;
  $('#pLogout').onclick = () => { localStorage.removeItem(SES_KEY); location.reload(); };
  $('#pReset').onclick = () => { if (confirm('Réinitialiser toute la progression de ce compte ?')) { localStorage.removeItem(GAME_CONFIG.saveKey); GAME_CONFIG.saveKey = null; location.reload(); } };
  $('#ownBtn').onclick = async () => {
    try { if (await ownerOk($('#ownCode').value)) { state.owner = true; $('#ownCode').value = ''; renderAll(); renderProfile(); notify('Mode owner activé 👑'); playSound('legendary-drop'); } else notify('Code incorrect', true); }
    catch (e) { notify('Navigateur non compatible (utilisez https ou localhost)', true); } };
  $('#chDrop').onchange = () => { state.cheats.drop = +$('#chDrop').value; saveGame(); };
  $('#chUp').onchange = () => { state.cheats.up100 = $('#chUp').checked; saveGame(); renderUpgrade(); };
  const give = ids => { ids.forEach(i => state.inv.push(newItem(i))); renderAll(); };
  $('#chAddBtn').onclick = () => { give([+$('#chAdd').value]); notify('Skin ajouté'); };
  $('#chAll').onclick = () => { give(SKINS.map(s => s.id)); notify('Collection débloquée'); };
  $('#chClear').onclick = () => { if (confirm("Vider l'inventaire ?")) { state.inv = []; renderAll(); } };
  $('#chOff').onclick = () => { state.owner = false; state.cheats = { drop: 0, up100: false }; renderAll(); renderProfile(); notify('Mode owner retiré'); };
}


// ===== BATAILLES D'OUVERTURE (2 joueurs, codes à usage unique) =====
// Les 10 drops (5 tours x 2 joueurs) sont déterminés par une graine commune : les deux joueurs voient exactement les mêmes résultats.
const BT = { rounds: 5, minStake: 10, maxStake: 1000000 };
const hashSeed = s => { let h = 1779033703 ^ s.length; for (let i = 0; i < s.length; i++) { h = Math.imul(h ^ s.charCodeAt(i), 3432918353); h = h << 13 | h >>> 19; } return h >>> 0; };
const mulberry = a => () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
const safeName = x => String(x || '').replace(/[^A-Za-z0-9_ -]/g, '').slice(0, 16) || 'Joueur';
function genBattle(seed) {
  const rng = mulberry(hashSeed(seed)), total = SKINS.reduce((a, k) => a + k.chance, 0), out = [];
  for (let i = 0; i < BT.rounds * 2; i++) {
    let r = rng() * total, pick = SKINS[0]; for (const k of SKINS) { if ((r -= k.chance) < 0) { pick = k; break; } }
    out.push({ id: pick.id, f: +rng().toFixed(6) });
  }
  return out;
}
const bVal = d => byId(d.id).price * wearMult(d.f);
const bTot = (b, p) => b.drops.reduce((a, d, k) => a + (k % 2 === p && k < b.step ? bVal(d) : 0), 0);
const myIdx = b => b.role === 'h' ? 0 : 1;
function startBattle(id, stake, seed, role, names, jc) { state.battle = { id, stake, seed, role, names, drops: genBattle(seed), step: 0, done: false, res: null, jc: jc || '' }; }
function showBCode(label, code) {
  $('#bOut').innerHTML = `<p>${label}</p><textarea readonly id="bOutTa">${code}</textarea><button id="bCopy">COPIER</button>`;
  $('#bCopy').onclick = () => { $('#bOutTa').select(); try { navigator.clipboard.writeText(code); } catch (e) { document.execCommand('copy'); } notify('Code copié'); };
}
function makeBattle() {
  const stake = Math.floor(+$('#bStake').value);
  if (!me) { notify('Connectez-vous d\'abord', true); return; }
  if (!(stake >= BT.minStake && stake <= BT.maxStake)) { notify(`Mise : ${BT.minStake} à ${fmt(BT.maxStake)} crédits`, true); return; }
  if (!state.owner && state.credits < stake) { notify('Crédits insuffisants', true); return; }
  const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 5).replace(/[^a-z0-9]/g, 'x'), seed = hex(crypto.getRandomValues(new Uint8Array(8)));
  const code = enc({ t: 'b', id, st: stake, sd: seed, n: safeName(me.name) });
  state.credits -= stake; (state.bpend = state.bpend || {})[id] = { stake, seed, c: code };
  renderAll(); showBCode(`Envoyez ce code à l'adversaire (votre mise de ${fmt(stake)} est bloquée). Puis importez le code de confirmation qu'il vous renverra :`, code);
}
function importBattle() {
  const raw = $('#bCode').value.trim(); let o;
  try {
    if (!raw.startsWith('CR1.')) throw 0; o = JSON.parse(atob(raw.slice(4)));
    if (typeof o.id !== 'string' || !/^[a-z0-9]{4,24}$/.test(o.id) || (o.t !== 'b' && o.t !== 'j')) throw 0;
    if (o.t === 'b' && (!Number.isInteger(o.st) || o.st < BT.minStake || o.st > BT.maxStake || typeof o.sd !== 'string' || !/^[a-f0-9]{16}$/.test(o.sd))) throw 0;
  } catch (e) { notify('Code invalide', true); return; }
  state.bpend = state.bpend || {};
  if (o.t === 'b') {
    if (state.bpend[o.id]) { notify("C'est votre propre bataille", true); return; }
    if (state.done.includes(o.id)) { notify('Code déjà utilisé', true); return; }
    if (state.battle) { notify('Terminez votre bataille en cours avant d\'en rejoindre une autre', true); return; }
    if (!state.owner && state.credits < o.st) { notify('Crédits insuffisants pour la mise', true); return; }
    if (!confirm(`Bataille contre ${safeName(o.n)}\nMise : ${fmt(o.st)} crédits chacun (pot : ${fmt(o.st * 2)})\n${BT.rounds} tours. Accepter ?`)) return;
    const jc = enc({ t: 'j', id: o.id, n: safeName(me.name) });
    state.credits -= o.st; state.done.push(o.id); startBattle(o.id, o.st, o.sd, 'g', [safeName(o.n), safeName(me.name)], jc);
    $('#bCode').value = ''; $('#bOut').innerHTML = ''; renderAll(); notify('Bataille acceptée !');
  } else {
    const p = state.bpend[o.id];
    if (!p) { notify('Aucune bataille en attente correspondante (ou code déjà utilisé)', true); return; }
    if (state.battle) { notify('Terminez votre bataille en cours d\'abord', true); return; }
    startBattle(o.id, p.stake, p.seed, 'h', [safeName(me.name), safeName(o.n)]); delete state.bpend[o.id];
    $('#bCode').value = ''; $('#bOut').innerHTML = ''; renderAll(); notify(`${safeName(o.n)} a rejoint la bataille !`);
  }
}
function finishBattle(b) {
  const t0 = bTot(b, 0), t1 = bTot(b, 1); b.done = true; b.res = t0 > t1 ? 0 : t1 > t0 ? 1 : -1;
  if (b.res === -1) state.credits += b.stake; else if (b.res === myIdx(b)) state.credits += b.stake * 2;
  playSound(b.res === myIdx(b) ? 'legendary-drop' : 'click');
}
async function battleStep() {
  const b = state.battle; if (!b || b.done || busy) return;
  busy = true; updateBalance(); renderBattle();
  const d = b.drops[b.step], s = byId(d.id);
  await animateRoulette(s, '#bBox', '#bTrack');
  playSound(s.rarity === 'mythic' ? 'knife-drop' : s.rarity === 'legendary' ? 'legendary-drop' : s.rarity === 'covert' || s.rarity === 'classified' ? 'rare-drop' : 'common-drop');
  b.step++; if (b.step >= BT.rounds * 2) finishBattle(b);
  busy = false; renderAll();
}
function renderBattle() {
  const b = state.battle, el = $('#bArena');
  $('#bPend').innerHTML = Object.entries(state.bpend || {}).map(([id, p]) => `<div class="pend"><b>Bataille ${id}</b> · mise ${fmt(p.stake)} crédits<br><button data-bcode="${id}">VOIR LE CODE</button> <button data-bcancel="${id}">ANNULER</button></div>`).join('') || '<small>Aucune bataille en attente.</small>';
  if (!b) { el.innerHTML = ''; $('#bBox').hidden = true; return; }
  const n = b.names, tot = [bTot(b, 0), bTot(b, 1)], cur = b.step % 2, me_ = myIdx(b);
  const col = p => { let h = ''; for (let r = 0; r < BT.rounds; r++) { const k = r * 2 + p; h += k < b.step ? cardHTML(byId(b.drops[k].id), '', '', b.drops[k]) : `<div class="card lock"><b>Tour ${r + 1}</b><em>—</em></div>`; }
    return `<div class="bcol${b.done && b.res === p ? ' win' : ''}"><h3>${n[p]}${p === me_ ? ' (vous)' : ''}</h3><div class="tot">Total : ${fmt(tot[p])} CRÉDITS</div><div class="grid">${h}</div></div>`; };
  let status, btn;
  if (b.done) {
    status = b.res === -1 ? `ÉGALITÉ — mise remboursée (+${fmt(b.stake)})` : b.res === me_ ? `🏆 VICTOIRE ! +${fmt(b.stake * 2)} CRÉDITS` : `DÉFAITE — ${fmt(b.stake)} crédits perdus`;
    btn = '<button class="cta" id="bLeave">QUITTER LA BATAILLE</button>';
  } else {
    status = `Tour ${Math.floor(b.step / 2) + 1} / ${BT.rounds} — au tour de ${n[cur]}`;
    btn = `<button class="cta" id="bGo" ${busy ? 'disabled' : ''}>${cur === me_ ? 'OUVRIR MA CAISSE' : `VOIR L'OUVERTURE DE ${n[cur].toUpperCase()}`}</button>`;
  }
  const jc = b.jc && b.step === 0 && !b.done ? `<p class="hint">Renvoyez ce code de confirmation à ${n[0]} pour qu'il lance la bataille de son côté :</p><textarea readonly id="bJc">${b.jc}</textarea><button id="bJcCopy">COPIER</button>` : '';
  el.innerHTML = `<div class="bhead"><b>${n[0]}</b><span class="vs">VS · MISE ${fmt(b.stake)} · POT ${fmt(b.stake * 2)}</span><b>${n[1]}</b></div>${jc}<div class="bstat">${status}</div><div class="bact">${btn}</div><div class="bcols">${col(0)}${col(1)}</div>`;
}
function initBattle() {
  $('#bMake').onclick = makeBattle; $('#bImport').onclick = importBattle;
  $('#bPend').onclick = e => { const c = e.target.closest('[data-bcode]'), x = e.target.closest('[data-bcancel]');
    if (c) showBCode('Code de votre bataille :', state.bpend[c.dataset.bcode].c);
    if (x && confirm('Annuler cette bataille et récupérer votre mise ?')) { const p = state.bpend[x.dataset.bcancel]; if (p) { state.credits += p.stake; delete state.bpend[x.dataset.bcancel]; $('#bOut').innerHTML = ''; renderAll(); notify(`+${fmt(p.stake)} crédits (mise récupérée)`); } } };
  $('#bArena').onclick = e => {
    if (e.target.closest('#bGo')) battleStep();
    else if (e.target.closest('#bLeave')) { if (!busy) { state.battle = null; renderAll(); } }
    else if (e.target.closest('#bJcCopy')) { $('#bJc').select(); try { navigator.clipboard.writeText(state.battle.jc); } catch (x) { document.execCommand('copy'); } notify('Code copié'); } };
}

document.addEventListener('mousemove', e => { const c = e.target.closest && e.target.closest('.grid .card,.rimg'); document.querySelectorAll('.tilting').forEach(x => { if (x !== c) { x.classList.remove('tilting'); const v = x.querySelector('svg'); if (v) v.style.transform = ''; } });
  if (!c) return; const v = c.querySelector('svg'); if (!v) return; const r = c.getBoundingClientRect(), dx = (e.clientX - r.left) / r.width - .5, dy = (e.clientY - r.top) / r.height - .5;
  c.classList.add('tilting'); v.style.transform = `perspective(400px) rotateY(${dx * 40}deg) rotateX(${-dy * 40}deg) scale(1.12)`; });
initExtra(); initGames(); initBattle(); initAuth();
init();
