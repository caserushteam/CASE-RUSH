# CaseRush — site web statique

Cette archive contient le site CaseRush prêt à être publié sur un hébergeur de sites statiques.

## Fichiers
- `index.html` : page du site
- `style.css` : styles et interface
- `script.js` : logique du jeu
- `.nojekyll` : évite certains traitements automatiques de GitHub Pages

## Tester sur son ordinateur
1. Décompressez l’archive.
2. Ouvrez un terminal dans le dossier `CaseRush-site`.
3. Lancez un petit serveur local :
   - Windows avec Python : `py -m http.server 8000`
   - ou macOS/Linux : `python3 -m http.server 8000`
4. Ouvrez `http://localhost:8000` dans votre navigateur.

Vous pouvez aussi ouvrir `index.html` directement, mais le serveur local est préférable pour les fonctions cryptographiques du navigateur.

## Publication gratuite avec GitHub Pages
1. Créez/connectez-vous à un compte sur https://github.com/.
2. Créez un nouveau dépôt, par exemple `caserush`. Pour un site public gratuit, choisissez **Public**.
3. Dans le dépôt, cliquez sur **Add file → Upload files**.
4. Envoyez les fichiers du dossier (les trois fichiers du site et `.nojekyll`, pas le dossier parent). `index.html` doit se trouver à la racine du dépôt.
5. Cliquez sur **Commit changes**.
6. Ouvrez **Settings → Pages**.
7. Dans **Build and deployment**, choisissez **Deploy from a branch**, puis `main` et `/ (root)`, puis **Save**.
8. Attendez la publication. L’adresse sera de la forme `https://VOTRE-PSEUDO.github.io/caserush/`.

Pour mettre le site à jour, renvoyez les fichiers modifiés dans le dépôt et validez les changements. GitHub Pages republiera le site automatiquement.

## Alternative simple : Netlify
1. Allez sur https://app.netlify.com/drop/ et connectez-vous.
2. Décompressez l’archive sur votre ordinateur.
3. Glissez-déposez le dossier `CaseRush-site` sur la zone de dépôt Netlify.
4. Netlify publie le site et fournit une adresse en `netlify.app`. Vous pourrez ensuite choisir un nom de site dans les paramètres.

## Limites importantes de cette version
Cette version est un **prototype front-end statique**. Elle ne possède pas de serveur ni de base de données.
- Les comptes, mots de passe et progressions sont stockés dans le navigateur (`localStorage`). Ils ne suivent pas automatiquement un joueur sur un autre appareil ou navigateur.
- L’inscription/connexion n’est donc pas une authentification sécurisée adaptée à un vrai service public. Le hachage du mot de passe est effectué côté navigateur et ne remplace pas un système d’authentification serveur.
- Le bouton Google n’est pas configuré (`googleClientId` est vide). Ne l’activez pas en production sans validation du jeton côté serveur.
- Les échanges et batailles par codes ne sont pas synchronisés par un serveur : le site lui-même précise qu’ils reposent sur la confiance entre joueurs.
- Les crédits et skins sont fictifs. N’ajoutez aucun paiement ni objet ayant une valeur réelle à cette version.

Pour obtenir de vrais comptes multi-appareils, des sauvegardes centralisées et des échanges fiables, il faudra développer un backend (API + base de données + authentification) et sécuriser les opérations côté serveur. L’hébergement statique seul ne suffit pas.

## Domaine personnalisé et HTTPS
GitHub Pages et Netlify fournissent une adresse HTTPS gratuite. Un nom de domaine personnalisé est facultatif et généralement payant. Configurez-le depuis les paramètres de l’hébergeur ; ne modifiez pas les DNS au hasard.
